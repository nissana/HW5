//
//  TabBarViewController.swift
//  HW5
//
//  Created by Nissana Akranavaseri on 3/4/15.
//  Copyright (c) 2015 NA. All rights reserved.
//

import UIKit

class TabBarViewController: UIViewController {

    @IBOutlet weak var loading1: UIImageView!
    @IBOutlet weak var loading2: UIImageView!
    @IBOutlet weak var loading3: UIImageView!
    @IBOutlet weak var bubble: UIImageView!
    
    @IBOutlet weak var neverMindView: UIView!
    @IBOutlet weak var neverMindButton: UIImageView!

    var bounce: Bool = true
    
    @IBOutlet weak var homeButton: UIButton!
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var composeButton: UIButton!
    @IBOutlet weak var accountButton: UIButton!
    @IBOutlet weak var trendingButton: UIButton!
    
    @IBOutlet weak var contentView: UIView!
    var currentViewController: UIViewController!
    
    //virtual containers in the main tabbarVC
    @IBOutlet weak var homeViewContainer: UIView!
    @IBOutlet weak var searchViewContainer: UIView!
    @IBOutlet weak var composeViewContainer: UIView!
    @IBOutlet weak var accountViewContainer: UIView!
    @IBOutlet weak var trendingViewContainer: UIView!

    
    //to instantiate from storyboards with coded classes
    var homeViewController: HomeViewController!
    var searchViewController: SearchViewController!
    var composeViewController: ComposeViewController!
    var accountViewController: AccountViewController!
    var trendingViewController: TrendingViewController!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var storyboard = UIStoryboard (name: "Main", bundle: nil)
        
        homeViewController = storyboard.instantiateViewControllerWithIdentifier("homeStory") as HomeViewController
        searchViewController = storyboard.instantiateViewControllerWithIdentifier("searchStory") as SearchViewController
        composeViewController = storyboard.instantiateViewControllerWithIdentifier("composeStory") as ComposeViewController
        accountViewController = storyboard.instantiateViewControllerWithIdentifier("accountStory") as AccountViewController
        trendingViewController = storyboard.instantiateViewControllerWithIdentifier("trendingStory") as TrendingViewController
        
        //assign virtual containers' frame to the instantVC.view.frame
        homeViewController.view.frame = homeViewContainer.frame
        searchViewController.view.frame = searchViewContainer.frame
        composeViewController.view.frame = composeViewContainer.frame
        accountViewController.view.frame = accountViewContainer.frame
        trendingViewController.view.frame = trendingViewContainer.frame
        
        //each virtualContainer.addSubview(instantVC.view)
        homeViewContainer.addSubview(homeViewController.view)
        searchViewContainer.addSubview(searchViewController.view)
        composeViewContainer.addSubview(composeViewController.view)
        accountViewContainer.addSubview(accountViewController.view)
        trendingViewContainer.addSubview(trendingViewController.view)
        
        //add to the object's VC
        addChildViewController(homeViewController)
        didMoveToParentViewController(self)
        addChildViewController(searchViewController)
        didMoveToParentViewController(self)
        addChildViewController(composeViewController)
        didMoveToParentViewController(self)
        addChildViewController(accountViewController)
        didMoveToParentViewController(self)
        addChildViewController(trendingViewController)
        didMoveToParentViewController(self)
        
        //not sure, if should be seperated
        //        homeViewController.didMoveToParentViewController(self)
        //        searchViewController.didMoveToParentViewController(self)
        //        composeViewController.didMoveToParentViewController(self)
        //        accountViewController.didMoveToParentViewController(self)
        //        trendingViewController.didMoveToParentViewController(self)
        
        //Initial assignment
        currentViewController = searchViewController
        loading ()
        delay(0.75, { () -> () in
            self.currentViewController.view.alpha = 0.3
            UIView.animateWithDuration(0.5, animations: { () -> Void in
                self.contentView.addSubview(self.currentViewController.view)
                self.currentViewController.view.alpha = 1
            })
        })
        bubble.alpha = 0
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
    //BUTTONS
    
    @IBAction func onTabHome(sender: UIButton) {
        showBubble()
        boucingBubble ()
        
        deselectButtons ()
        homeButton.selected = true
        
        removeChildView(currentViewController)
        //removeChildView(searchViewController)
        
        currentViewController = homeViewController
        contentView.addSubview(currentViewController.view)
        //contentView.frame = currentViewController.view.frame
        //println("currentViewController: \(currentViewController) contentView: \(contentView)")
    }
    
    @IBAction func onTabSearch(sender: UIButton) {
        showBubble()
        
        deselectButtons ()
        searchButton.selected = true
        
        removeChildView(currentViewController)
        removeChildView(trendingViewController)
        currentViewController = searchViewController
        
        loading ()
        delay(0.75, { () -> () in
            self.currentViewController.view.alpha = 0.3
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.contentView.addSubview(self.currentViewController.view)
                self.currentViewController.view.alpha = 1
            })
        })

        hideBubble()
    }
    
    @IBAction func onTabCompose(sender: UIButton) {
        showBubble()

        deselectButtons ()
        composeButton.selected = true
        bubble.alpha = 0.3 //0.5
        
        currentViewController = composeViewController
        contentView.addSubview(currentViewController.view)
  
        neverMindView.hidden = false
        neverMindButton.hidden = false
        

        //performSegueWithIdentifier("composeSeque", sender: self)
    }
    
    @IBAction func onDismissCompose(sender: UITapGestureRecognizer) {
        //animate out
        
        self.removeChildView(self.composeViewController)
        contentView.addSubview(composeViewController.view)

        
        delay(1, { () -> () in
            self.removeChildView(self.composeViewController)
            self.neverMindView.hidden = true
            self.neverMindButton.hidden = true
            self.bubble.alpha = 1

        })
    }
    
    @IBAction func onTabAccount(sender: UIButton) {
        showBubble()

        deselectButtons ()
        accountButton.selected = true
        
        removeChildView(currentViewController)
        //removeChildView(searchViewController)
        currentViewController = accountViewController
        contentView.addSubview(currentViewController.view)
    }
    
    @IBAction func onTabTrending(sender: UIButton) {
        showBubble()
        
        deselectButtons ()
        trendingButton.selected = true
        
        removeChildView(currentViewController)
        //removeChildView(searchViewController)
        currentViewController = trendingViewController
        contentView.addSubview(currentViewController.view)

//        loading ()
//        delay(0.75, { () -> () in
//            self.currentViewController.view.alpha = 0.3
//            UIView.animateWithDuration(0.3, animations: { () -> Void in
//                self.contentView.addSubview(self.currentViewController.view)
//                self.currentViewController.view.alpha = 1
//            })
//        })
    }
    
    
    //REMOVE CHILD
    func removeChildView(content: UIViewController){ //A, B, C
        content.willMoveToParentViewController(nil)
        content.view.removeFromSuperview()
        content.removeFromParentViewController()
    }
    
    //Loading
    func loading (){
        loading1.hidden = false
        loading2.hidden = false
        loading3.hidden = false
        
        delay(0.25, { () -> () in
            self.loading1.hidden = true
        })
        delay(0.5, { () -> () in
            self.loading2.hidden = true
        })
        delay(0.75, { () -> () in
            self.loading3.hidden = true
        })
    }
    
    //Bouncing bubble
    func boucingBubble () {
        var startingY = self.bubble.center.y
        UIView.animateWithDuration(1, delay: 0.5, options: UIViewAnimationOptions.Repeat | UIViewAnimationOptions.Autoreverse, animations: { () -> Void in
            self.bubble.center.y = self.bubble.center.y + 10.0
        }) { (Bool) -> Void in
            self.bubble.center.y = startingY}
    }
    //func stopBouncing () {
        //bubble.alpha = 1
        //self.bubble.layer.removeAllAnimations()
    //}
    func hideBubble(){
        bubble.alpha = 1
        bubble.layer.zPosition = 0
        UIView.animateWithDuration(0.5, animations: { () -> Void in
            self.bubble.alpha = 0
        })
    }
    func showBubble(){
        bubble.layer.zPosition = 10
        UIView.animateWithDuration(0.5, animations: { () -> Void in
        self.bubble.alpha = 1
        })
    }
    
    //click button: sender.selected = !sender.selected
    func deselectButtons (){
        homeButton.selected = false
        searchButton.selected = false
        composeButton.selected = false
        accountButton.selected = false
        trendingButton.selected = false
    }

}
