//
//  HomeViewController.swift
//  HW5
//
//  Created by Nissana Akranavaseri on 3/4/15.
//  Copyright (c) 2015 NA. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var loginBg: UIView!
    @IBOutlet weak var loginImageView: UIImageView!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var emailTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        reset()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func logIn(sender: UIButton) {
        delay(0.3, { () -> () in
            self.loginBg.alpha = 1
            self.loginImageView.alpha = 1
            self.cancelButton.alpha = 1
            self.emailTextField.alpha = 1
        })
  
    }
    
    @IBAction func cancelButton(sender: AnyObject) {
        cancelButton.backgroundColor = UIColor (red: 32/255.0, green:251/255.0, blue:226/255.0, alpha:0.5) //#20FBE2

        delay(0.3, { () -> () in
            self.emailTextField.alpha = 0

            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.reset()
                self.view.endEditing(true)
            })
        })
    }

    func reset () {
        cancelButton.backgroundColor = UIColor.clearColor()
        
        loginBg.alpha = 0
        loginImageView.alpha = 0
        cancelButton.alpha = 0
        emailTextField.alpha = 0

    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
