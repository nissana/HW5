
//
//  ComposeViewController.swift
//  HW5
//
//  Created by Nissana Akranavaseri on 3/4/15.
//  Copyright (c) 2015 NA. All rights reserved.
//

import UIKit

class ComposeViewController: UIViewController, UIViewControllerTransitioningDelegate {
    //}, UIViewControllerAnimatedTransitioning {
    
    @IBOutlet weak var textButton_1: UIButton!
    @IBOutlet weak var photoButton_2: UIButton!
    @IBOutlet weak var quoteButton_3: UIButton!
    @IBOutlet weak var linkButton_4: UIButton!
    @IBOutlet weak var chatButton_5: UIButton!
    @IBOutlet weak var videoButton_6: UIButton!
    
    var row1y: CGFloat!
    var row2y: CGFloat!
    let offTop: CGFloat! = -100
    let offBottom: CGFloat! = 700
    var inOut: Bool = false
    var i = 0
    
//    var isPresenting: Bool = true
//    var interactiveTransition: UIPercentDrivenInteractiveTransition!
//    var duration: NSTimeInterval! = 0.5
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Ending center position
        row1y = textButton_1.center.y
        row2y = linkButton_4.center.y
        
        //hide buttons
        textButton_1.hidden = true
        photoButton_2.hidden = true
        quoteButton_3.hidden = true
        linkButton_4.hidden = true
        chatButton_5.hidden = true
        videoButton_6.hidden = true
        
        //set bottom off-screen
        resetButtons ()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        modalPresentationStyle = UIModalPresentationStyle.Custom
        transitioningDelegate = self
    }
    

    override func viewDidAppear(animated: Bool) {
        if i == 0 {
        //initial 0 - don't do anything, hack with tab
        }
        else if i == 1 {
           animateButtonsOut()
        }
        else {
            animateButtonsIn()
        }

    }

    
    func animateButtonsIn () {
        //options: UIViewAnimationOptions.CurveEaseInOut
        
        showButtons ()
        
        UIView.animateWithDuration(1, animations: { () -> Void in
            self.textButton_1.center.y = self.row1y
        })
        UIView.animateWithDuration(0.4, animations: { () -> Void in
            self.photoButton_2.center.y = self.row1y
        })
        UIView.animateWithDuration(0.8, animations: { () -> Void in
            self.quoteButton_3.center.y = self.row1y
        })
        UIView.animateWithDuration(1.1, animations: { () -> Void in
            self.linkButton_4.center.y = self.row2y
        })
        UIView.animateWithDuration(0.6, animations: { () -> Void in
            self.chatButton_5.center.y = self.row2y
        })
        UIView.animateWithDuration(1.2, animations: { () -> Void in
            self.videoButton_6.center.y = self.row2y
        })
        
        i = 1

    }
    
    func animateButtonsOut () {
        
        //println("running  OUT")
        
        UIView.animateWithDuration(1, animations: { () -> Void in
            self.textButton_1.center.y = self.offTop
        })
        UIView.animateWithDuration(0.4, animations: { () -> Void in
            self.photoButton_2.center.y = self.offTop
        })
        UIView.animateWithDuration(0.8, animations: { () -> Void in
            self.quoteButton_3.center.y = self.offTop
        })
        UIView.animateWithDuration(1.1, animations: { () -> Void in
            self.linkButton_4.center.y = self.offTop
        })
        UIView.animateWithDuration(0.6, animations: { () -> Void in
            self.chatButton_5.center.y = self.offTop
        })
        UIView.animateWithDuration(1.2, animations: { () -> Void in
            self.videoButton_6.center.y = self.offTop
        })
        
        i++
    }
    
    
    @IBAction func tapIn(sender: AnyObject) {
        i = 1 //set ready to animate in
        //println("i \(i)")
        animateButtonsIn()
    }
    @IBAction func tapOut(sender: AnyObject) {
        animateButtonsOut ()
    }

    
    func showButtons() {
        resetButtons()
        textButton_1.hidden = false
        photoButton_2.hidden = false
        quoteButton_3.hidden = false
        linkButton_4.hidden = false
        chatButton_5.hidden = false
        videoButton_6.hidden = false
    }
    func resetButtons() {
        //set bottom off-screen
        textButton_1.center.y = offBottom
        photoButton_2.center.y = offBottom
        quoteButton_3.center.y = offBottom
        linkButton_4.center.y = offBottom
        chatButton_5.center.y = offBottom
        videoButton_6.center.y = offBottom
    }

}
